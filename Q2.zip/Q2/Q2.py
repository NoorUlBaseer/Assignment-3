"""
Question-2:
Guess the hidden word by suggesting letters one at a time.
You have a limited number of attempts before the "hangman" is complete.

Instructions:
1.	The computer selects a random word from a predefined list.
2.	The game displays the number of letters in the word as underscores, representing unguessed letters.
3.	You guess a letter by entering it.
4.	If the guessed letter is in the word, the corresponding underscores are replaced with the letter.
5.	If the guessed letter is not in the word, a part of the hangman is drawn (e.g., head, body, arms, legs).
6.	You continue guessing letters until you either guess the word correctly or the hangman is fully drawn.
7.	If you guess the word, you win! If the hangman is fully drawn before you guess the word, you lose.
"""

import hangman_art
import hangman_words
import random

logo = hangman_art.logo
print(logo)

word_list = hangman_words.word_list
chosen_word = random.choice(word_list)
#print(chosen_word)

stages = hangman_art.stages
#print(stages[0])

length = len(chosen_word)
progress = ["_"] * length
print(" ".join(progress))

print()
live=6
loop_count=1
while live>0:
    guess_letter=input("Enter a letter: ")
    present= False
    for i in range(0,length):
        if guess_letter == chosen_word[i]:
            present = True
            progress[i] = guess_letter
    print(" ".join(progress))

    if present == True:
        print(stages[live])
    elif present == False:
        print(guess_letter, "is not present in the word")
        print("You lose a live")
        if loop_count==1:
            live=5
            print(stages[live])
        else:
            live-=1
            print(stages[live])

    if "_" not in progress:
        print("Congratulations! You guessed the word:", chosen_word)
        break
    loop_count+=1

if live == 0:
    print("You lose! The word was:", chosen_word)
